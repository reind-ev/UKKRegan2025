<?php
// Koneksi ke database
$koneksi = new mysqli("localhost", "root", "", "ukk2025");

// Mengecek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_barang.xls");
?>

<table border="1">
    <tr>
        <th>ID Barang</th>
        <th>Nama Barang</th>
        <th>Kategori</th>
        <th>Jumlah Stok</th>
        <th>Harga</th>
        <th>Tanggal Masuk</th>
    </tr>

    <?php
    $query = "SELECT * FROM ukkbarang";
    $result = $koneksi->query($query);

    // Mengecek apakah query berhasil
    if ($result) {
        // Mengecek apakah ada data
        if ($result->num_rows > 0) {
            // Menampilkan data
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['ID_barang'] . "</td>";
                echo "<td>" . $row['Nama_barang'] . "</td>";
                echo "<td>" . $row['kategori'] . "</td>";
                echo "<td>" . $row['Jumlah_stok'] . "</td>";
                echo "<td>" . number_format($row['harga'], 0, ',', '.') . "</td>";  // Format harga
                // Format tanggal agar sesuai dengan format Excel
                $tanggalMasuk = date('Y-m-d', strtotime($row['tanggal_masuk']));
                echo "<td>" . $tanggalMasuk . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>Data tidak ditemukan</td></tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Query Error: " . $koneksi->error . "</td></tr>";
    }
    $koneksi->close();
    ?>
</table>

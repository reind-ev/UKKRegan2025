<?php
include 'koneksi.php';

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM ukkbarang WHERE ID_barang = '$id'");
$row = mysqli_fetch_assoc($data);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['Nama_barang'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['Jumlah_stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    mysqli_query($koneksi, "UPDATE ukkbarang SET 
        Nama_barang = '$nama', 
        kategori = '$kategori', 
        Jumlah_stok = '$stok', 
        harga = '$harga', 
        tanggal_masuk = '$tanggal' 
        WHERE ID_barang = '$id'");

    header("Location: index.php?pesan=update");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="shortcut icon" href="inventory.png">
    <style>
        body {
            font-family: sans-serif;
            background-color: #f1f7f4;
            padding: 30px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        .form-container {
            width: 50%;
            margin: 0 auto;
            background: #ffffff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
        }
        td {
            padding: 10px;
        }
        input[type="text"], input[type="number"], input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        a {
            text-decoration: none;
            color: #fff;
            background-color: #dc3545;
            padding: 10px 20px;
            border-radius: 4px;
            margin-left: 10px;
        }
        .button-row {
            text-align: center;
            margin-top: 20px;
        }
        .navbar {
            font-family: lucida handwriting;
            background: linear-gradient(90deg,rgb(143, 156, 83),rgb(239, 162, 67));
            overflow: hidden;
            margin-bottom: 30px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 999;
            font-family: lucida handwriting;
    }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 18px;
            text-decoration: none;
            font-size: 16px;
            background-color: transparent;
            border: none;
        }


        .navbar a:hover {
            background-color: #fff;
            color:rgb(0, 0, 0);
}


        .dropdown {
            float: left;
            overflow: hidden;
    }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            z-index: 1;
    }

        .dropdown:hover .dropdown-content {
            display: block;
    }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="index.php">🏠 Home</a>
    </div>
    <h2>Edit Data Barang</h2>
    <div class="form-container">
        <form method="POST">
            <table>
                <tr>
                    <td><label>Nama Barang:</label></td>
                    <td><input type="text" name="Nama_barang" value="<?= $row['Nama_barang']; ?>"></td>
                </tr>
                <tr>
                    <td><label>Kategori:</label></td>
                    <td><input type="text" name="kategori" value="<?= $row['kategori']; ?>"></td>
                </tr>
                <tr>
                    <td><label>Stok:</label></td>
                    <td><input type="number" name="Jumlah_stok" value="<?= $row['jumlah_stok']; ?>"></td>
                </tr>
                <tr>
                    <td><label>Harga:</label></td>
                    <td><input type="text" name="harga" value="<?= $row['harga']; ?>"></td>
                </tr>
                <tr>
                    <td><label>Tanggal Masuk:</label></td>
                    <td><input type="date" name="tanggal_masuk" value="<?= $row['tanggal_masuk']; ?>"></td>
                </tr>
            </table>
            <div class="button-row">
                <button type="submit">Update</button>
                <a href="index.php">Kembali</a>
            </div>
        </form>
    </div>

</body>
</html>

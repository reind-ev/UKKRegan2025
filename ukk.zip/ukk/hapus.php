<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM ukkbarang WHERE ID_barang = '$id'");
}

header("Location: index.php?pesan=hapus");
exit;
?>

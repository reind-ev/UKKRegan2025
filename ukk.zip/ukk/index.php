<!DOCTYPE html>
<html>
<head>
    <title>Inventaris Barang</title>
    <link rel="shortcut icon" href="inventory.png">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
            background-color:rgb(251, 251, 251);
            margin-top: 70px;
        }

        h2 {
            text-align: center;
            font-weight: bold;
            color: #333;
        }

        .navbar {
            background: linear-gradient(90deg,rgb(143, 156, 83),rgb(239, 162, 67));
            overflow: visible;
            padding: 10px 0;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 999;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 18px;
            text-decoration: none;
            font-size: 16px;
        }

        .navbar a:hover {
            background-color: #fff;
            color:rgb(0, 0, 0);
        }

        /* Dropdown */
        .dropdown {
            float: left;
            position: relative;
        }

        .dropdown a {
            padding: 14px 18px;
            display: block;
            text-align: center;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            top: 50px; /* biar turun dari navbar */
            left: 0;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 1000;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .navbar .btn-tambah {
            float: right;
            background-color: transparent;
            color: white;
            border-radius: 5px;
            padding: 14px 18px;
            margin-right: 16px;
            font-size: 16px;
            text-decoration: none;
        }

        .navbar .btn-tambah:hover {
            background-color: #fff;
            color:rgb(0, 0, 0);
        }

        .table-container {
            width: 90%;
            margin: 0 auto;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        th {
            background-color:rgb(199, 248, 202);
            color: black;
            padding: 12px;
            text-align: center;
        }

        td {
            padding: 10px 15px;
            border-bottom: 1px solid #eee;
            text-align: center;
            color: #444;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .filter-letters button {
            padding: 6px 12px;
            margin: 2px;
            background-color: rgb(0, 187, 255);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-edit, .btn-hapus {
            padding: 6px 12px;
            margin: 0 2px;
            border: none;
            border-radius: 4px;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-edit {
            background-color:rgb(0, 0, 0);
        }

        .btn-hapus {
            background-color: #dc3545;
        }
        .notif-box {
            position: relative;
            width: 80%;
            margin: 10px auto;
            padding: 10px 40px 10px 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            opacity: 1;
            transition: opacity 0.5s ease;
        }
        .close-btn {
            position: absolute;
            top: 50px;
            right: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 18px;
        }
        .btn-export {
            padding: 12px 24px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
}

        .btn-export:hover {
    background-color: #45a049;
    transform: scale(1.05);
}

.btn-export:active {
    background-color: #3e8e41;
    transform: scale(0.98);
}

    </style>
</head>
<body>
<script>
    function tutupNotif() {
        const notif = document.getElementById("notif");
        notif.style.opacity = '0';
        setTimeout(() => {
            notif.style.display = 'none';
        }, 500);
    }

    // Biar notifikasi ilang otomatis setelah 5 detik
    window.onload = function () {
    const notif = document.getElementById("notif");

    if (!sessionStorage.getItem('notifShown') && notif) {
        // Menampilkan notifikasi hanya jika belum pernah ditampilkan
        notif.style.opacity = '1';
        notif.style.display = 'block'; // Pastikan tampilkan notif

        // Setelah 5 detik, hilangkan notifikasi
        setTimeout(() => {
            notif.style.opacity = '0';
            setTimeout(() => {
                notif.style.display = 'none';
            }, 500); // waktu fade out-nya 0.5 detik
        }, 5000); // ilang setelah 5 detik

        // Tandai bahwa notifikasi sudah ditampilkan
        sessionStorage.setItem('notifShown', 'true');
    }
}
</script>

<div class="navbar">
    <a href="index.php">🏠 HOME</a>
    
    
    <!-- Dropdown Filter -->
    <div class="dropdown">
        <a href="#">Filter</a>
        <div class="dropdown-content">
            <a href="index.php?kategori=Elektronik">Elektronik</a>
            <a href="index.php?kategori=Alat Tulis">Bacaan</a>
            <a href="index.php?kategori=Pakaian">Pakaian</a>
            <a href="index.php?kategori=Minuman">Minuman</a>
            <a href="index.php?kategori=Makanan">Makanan</a>
            <a href="index.php?kategori=Furniture">Furniture</a>
            <a href="index.php">All</a>
        </div>
    </div>
    
    <a href="tambah.php" class="btn-tambah">Tambah</a>
    <?php
include 'koneksi.php';
$query = mysqli_query($koneksi, "SELECT ID_barang FROM ukkbarang LIMIT 1");
$first_id = mysqli_fetch_assoc($query)['ID_barang'];
?>

</div>
<h2>Inventaris Barang</h2>
<div class="filter-letters" style="text-align: center; margin: 10px 0;">
    <strong>Search(A-Z):</strong><br>
    <div style="overflow-x: auto; white-space: nowrap;">
        <?php foreach (range('A', 'Z') as $letter): ?>
            <button onclick="filterHuruf('<?= $letter ?>')"><?= $letter ?></button>
        <?php endforeach; ?>
        <button onclick="filterHuruf('')">Semua</button>
    </div>
</div>
<?php 
    if (isset($_GET['pesan'])) {
    echo "<div id='notif' class='notif-box'>
            <span class='close-btn' onclick='tutupNotif()'>&times;</span>";
        if ($_GET['pesan'] == 'update') echo "✅ Data berhasil diubah!";
        if ($_GET['pesan'] == 'hapus') echo "🗑️ Data berhasil dihapus!";
        if ($_GET['pesan'] == 'tambah') echo "➕ Data berhasil ditambahkan!";
    echo "</div>";
    }
?>
    </div>
<div class="table-container">
<table id="ukkbarang">
        <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Harga</th>
        <th>Tanggal Masuk</th>
        <th>Option</th>
    </tr>
    <?php
    include 'koneksi.php';
    $no = 1;
    $filterHuruf = isset($_GET['huruf']) ? $_GET['huruf'] : '';
    $filterKategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

$sql = "SELECT * FROM ukkbarang WHERE 1";

if (!empty($filterHuruf)) {
    $sql .= " AND Nama_barang LIKE '$filterHuruf%'";
}

if (!empty($filterKategori)) {
    $sql .= " AND kategori = '$filterKategori'";
}

$query = mysqli_query($koneksi, $sql);

    while ($data = mysqli_fetch_array($query)) {
        echo "<tr>
            <td>{$no}</td>
            <td>{$data['Nama_barang']}</td>
            <td>{$data['kategori']}</td>
            <td>{$data['Jumlah_stok']}</td>
            <td>Rp " . number_format($data['harga'], 0, ',', '.') . "</td>
            <td>{$data['tanggal_masuk']}</td>
            <td>
                <a class='btn-edit' href='edit.php?id={$data['ID_barang']}'>Edit</a>
                <a class='btn-hapus' href='hapus.php?id={$data['ID_barang']}' onclick='return confirm(\"Yakin pengen ngehapus?\")'>Hapus</a>
            </td>
        </tr>";
        $no++;
    }
    ?>
    
</table>
</div>
<div style="text-align: center; margin-top: 20px;">
  <button onclick="exportToExcel()" class="btn-export">Export ke Excel</button>
</div>
<script>
    function exportToExcel(){
        window.location.href = "excel.php"
    }
</script>
<script>
    function filterHuruf(huruf) {
    const urlParams = new URLSearchParams(window.location.search);

    urlParams.delete('pesan');

    if (huruf) {
        urlParams.set('huruf', huruf);
    } else {
        urlParams.delete('huruf');
    }

    window.location.search = urlParams.toString();
}
</script>

</body>
</html>

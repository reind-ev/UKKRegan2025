<?php
include 'koneksi.php';

// Proses simpan data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['Nama_barang'];
    $kategori = $_POST['kategori'];
    $stok = $_POST['Jumlah_stok'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal_masuk'];

    // Validasi jika stok negatif
    if ($stok <= 0) {
        echo "<script>alert('Stok Jangan Negatif! Ataupun 0!!');</script>";
    } else {
        $query = "INSERT INTO ukkbarang (Nama_barang, kategori, Jumlah_stok, harga, tanggal_masuk)
                  VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal')";

        $insert = mysqli_query($koneksi, $query);

        if ($insert) {
            header("Location: index.php?pesan=tambah");
            exit;
        } else {
            echo "Gagal menambahkan Data: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="inventory.png">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #74ebd5, #ACB6E5);
            margin: 0;
            padding: 0;
        }

        .navbar {
            font-family: 'Lucida Handwriting', cursive;
            background: linear-gradient(90deg,rgb(143, 156, 83),rgb(239, 162, 67));
            padding: 12px 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 16px;
            border-radius: 8px;
        }

        .navbar a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
        }

        .card {
            background: #ffffffcc;
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            padding: 25px;
        }

        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }

        .btn-custom {
            border: none;
            padding: 10px 20px;
            font-weight: bold;
            border-radius: 8px;
        }

        .btn-danger {
            background-color: #ff4e50;
        }

        .btn-danger:hover {
            background-color: #d43f3a;
        }

        .btn-primary {
            background-color: #5f2c82;
        }

        .btn-primary:hover {
            background-color: #4e2672;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <a href="index.php">🏠 Home</a>
    </div>

    <div class="container">
        <div class="card">
            <h2>Tambah Barang Baru</h2>

            <form action="tambah.php" method="POST" onsubmit="return validasiForm()">
                <div class="mb-3">
                    <label class="form-label">Nama Barang</label>
                    <input type="text" name="Nama_barang" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <input type="text" name="kategori" class="form-control" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="Jumlah_stok" id="Jumlah_stok" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Harga</label>
                    <input type="number" name="harga" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal Masuk</label>
                    <input type="date" name="tanggal_masuk" class="form-control" required>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-danger btn-custom">+ Tambah</button>
                    <a href="index.php" class="btn btn-primary btn-custom">← Kembali</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Fungsi validasi untuk cek stok
        function validasiForm() {
            var stok = document.getElementById("Jumlah_stok").value;

            // Cek apakah stok adalah angka negatif
            if (stok < 0) {
                alert("Stok Jangan Negatif! Input denied");  // Menampilkan pesan peringatan
                return false;  // Mencegah form untuk disubmit
            }
            return true;  // Melanjutkan submit form jika valid
        }
    </script>

</body>
</html>
